var chai = require('chai');
var expect = chai.expect;

describe('test suite for mocha',function(){
    context('current execution context',function(){
        it('first unit test using mocha & chai',function(){
            // assertion using chai !
            // expect(10).to.equal(10);
            // expect({name:'Synechron'}).to.deep.equal({name:'Synechron'})
            expect(5 > 8).to.be.false;
        });    
    });
})