var assert = require('assert'); // default package available

describe('test suite for mocha',function(){
    context('current execution context',function(){
        it('first unit test using mocha',function(){
            // assertion
            assert.equal(10,10);
        });

        it('deepEqual ',function(){
            // assertion
            assert.deepEqual({name:'Synechron'},{name:'Synechron'})
        });
    })
})