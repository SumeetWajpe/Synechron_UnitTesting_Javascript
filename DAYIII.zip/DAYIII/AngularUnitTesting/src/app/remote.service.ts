import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RemoteService {

  constructor(private httpObj:HttpClient) { }

  fetchViaHttp():Observable<any>{
    return this.httpObj.get('https://jsonplaceholder.typicode.com/posts');
  }
}
