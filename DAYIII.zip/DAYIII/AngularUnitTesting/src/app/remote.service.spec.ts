import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController} from
   '@angular/common/http/testing';
import { RemoteService } from './remote.service';

describe('RemoteService', () => {
  let serviceObj:RemoteService;
  let httpMock:HttpTestingController;
  beforeEach(() => { TestBed.configureTestingModule({
    imports:[HttpClientTestingModule],
    providers:[RemoteService]
  })// eof configureTestingModule
  serviceObj = TestBed.get(RemoteService);
  httpMock = TestBed.get(HttpTestingController);
});// eof beforeEach

  it('should be created', () => {
    const service: RemoteService = TestBed.get(RemoteService);
    expect(service).toBeTruthy();
  });

  it('mock the http call',()=>{
    serviceObj.fetchViaHttp().subscribe(
      response => expect(response.name).toBe('Synechron')
    );

    let req = httpMock.expectOne('https://jsonplaceholder.typicode.com/posts',
    'call to the API')
    expect(req.request.method).toBe('GET');
    req.flush({
      name:'Synechron'
    });
  });
});
