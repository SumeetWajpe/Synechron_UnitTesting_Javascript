self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "8c194df94bf42d966df7",
    "url": "/static/js/main.ec3197e7.chunk.js"
  },
  {
    "revision": "45124f853ba07aa965c0",
    "url": "/static/js/2.6efc73d3.chunk.js"
  },
  {
    "revision": "8c194df94bf42d966df7",
    "url": "/static/css/main.f4cd1033.chunk.css"
  },
  {
    "revision": "9c0e5a8c9bfca69a7a6c07620bc3dacb",
    "url": "/index.html"
  }
];