describe('Suite to test Add',function(){
        it('adds two numbers',function(){
            expect(Add(10,20)).toBe(40);
        });
});