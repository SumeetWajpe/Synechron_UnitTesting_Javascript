describe('use basic matchers',function(){
    xit('use of toBe:===',function(){
        // expect('60').toBe(60);
         expect(60).toBe(60);

    });

    xit('use of toEqual:=== + object inspection',function(){
        // expect(60).toEqual(60);
        // expect({name:'Synechron'}).toEqual({name:'Synechrone'})
        expect([1,2,3]).toEqual([1,2,3]);
    });

    xit('use of toMatch: regEx',function(){
           expect('company').toMatch(/company/);
        expect('Company').toMatch(/company/i);

    });

    xit('use of toBeUndefined',function(){
        var obj = {};
        expect(obj.anyproperty).not.toBeDefined();   
 });

//  it('use of toContain',function(){
//     var str = "Synechron is a company";
//     // expect(str).toContain("company"); 
//     var person = ["Sumeet",'Pune'];
//     expect(person).toContain("Pune");  
// });


function ThisThrowsAnError(){
    throw new TypeError('My Exception')
}
it('use of toThrowError',function(){  
 expect(ThisThrowsAnError).toThrowError(TypeError);
});
function ThisDoesNotThrowAnError(){
       return 10;
}
it('use of not.toThrow',function(){  
    expect(ThisDoesNotThrowAnError).not.toThrow();
});
});