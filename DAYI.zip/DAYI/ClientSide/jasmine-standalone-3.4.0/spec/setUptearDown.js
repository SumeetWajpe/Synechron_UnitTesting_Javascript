describe('use of setup/teardown',function(){ 
    var arr;
    beforeEach(function(){
        arr =  [10,20,30];  
        console.log('Before Each called..')
    });
    beforeAll(function(){
        console.log('Before All called..')
    });   
    it('use of toContain',function(){
        console.log('toBe Test executed..')
        expect(arr).toContain(20);
    });
    it('use of toEqual',function(){
        console.log('toEqual Test executed..')
        expect(60).toEqual(60);
    });
    afterEach(function(){
        console.log('After Each called..');
        arr = null;
    });
    afterAll(function(){
        console.log('After All called..')
    });
});