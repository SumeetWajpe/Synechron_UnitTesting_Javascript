describe('First Test Suite',function(){
    it('check 10 to be 10',function(){
        expect(10).toBe(20);
    })
})