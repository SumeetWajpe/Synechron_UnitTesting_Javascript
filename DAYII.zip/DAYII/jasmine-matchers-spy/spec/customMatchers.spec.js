describe('custom Matchers',function(){
    it('checks the type',function(){
        expect([]).toBeOfType('number','Not a number')
    });   
});