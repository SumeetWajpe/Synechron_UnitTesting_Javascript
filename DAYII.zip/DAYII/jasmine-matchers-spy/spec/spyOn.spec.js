describe('Basic Spying', function () {
    beforeEach(function () {
        this.increment = function (x) {
            return x + 1;
        }
        // spyOn(object,method)
        spyOn(this, 'increment');// set the spy !
    });// eof beforeEach


    it('spyon a function', function () {
        this.increment(20);
        expect(this.increment).toHaveBeenCalled();
    });

    xit('spyon a function check return value', function () {
       var nextVal = this.increment(20);
        expect(nextVal).toBeDefined();
    });

    it('spyon a function check return value with callThrough', function () {
        
        this.increment.and.callThrough(); // places a call !
        var nextVal = this.increment(20);
         expect(nextVal).toBeDefined();
         expect(nextVal).toBe(21);
     });

     it('spyon a function with parameters', function () {
        this.increment.and.callThrough(); 
        this.increment(20);
        expect(this.increment).toHaveBeenCalledWith(20);
    });

    it('spyon a function with return value', function () {
        this.increment.and.returnValue(100)
        var nextVal = this.increment(20);
        expect(nextVal).toBe(100);
    });

    it('spyon a function with callFake', function () {
        this.increment.and.callFake(function(x){
            return x * 2;
        });
        var nextVal = this.increment(20);
        expect(nextVal).toBe(40);
    });

    it('spyon a function for invocation count', function () {
        this.increment(20);
        this.increment(20);
        this.increment(20);
        this.increment(20);
        this.increment(20);

        expect(this.increment.calls.count()).toBe(5);
    });


});

