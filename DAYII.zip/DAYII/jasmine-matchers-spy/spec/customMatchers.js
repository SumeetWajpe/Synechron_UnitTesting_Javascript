var customMatchers = {
    toBeOfType:function(util,customEqualityTesters){
            return {
                compare:function(actual,expected,message){
                    var result ={};   
                    if(typeof expected == 'string'){
                                result.pass = util.equals(typeof actual,expected,customEqualityTesters);
                                if(result.pass){
                                    result.message = "Expected " + typeof actual + " to not be" + expected + " " + message;
                                }else{
                                    result.message = "Expected " + typeof actual + " to be " + expected + " " + message;
                                }
                        }else if(typeof expected === 'function'){
                                result.pass = actual instanceof expected;
                                if(result.pass){
                                    result.message = "Expected " + actual + " to not be an instance of" + expected;
                                }else{
                                    result.message = "Expected " + typeof actual + " to be an instance of " + expected;
                                }
                        }
                        return result;
                }
            }
    }
}

beforeEach(function(){
    jasmine.addMatchers(customMatchers);
})