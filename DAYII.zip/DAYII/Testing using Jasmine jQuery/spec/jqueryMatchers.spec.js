describe('jquery Matchers',function(){

xit('form elements',function(){
    // matcher is given by jasmine-jquery.js
    expect($("input[type='checkbox']")).toBeChecked(); 
    expect($("input[type='text']")).toHaveValue('disabled textbox')
});
xit('dom',function(){
    //1.
    // $("input[type='checkbox']").focus(); // event
    // expect($("input[type='checkbox']")).toBeFocused();
    //2.
    //expect($('input')).toHaveLength(2);
    //3.
    // expect($('div')).toBeInDOM();
    //expect($('#hidden')).toBeHidden();
       //expect($("input[type='text']")).toBeMatchedBy('[value="disabled textbox"]')
    //    expect($("input[type='text']")).toHaveAttr('disabled');
    // expect($("input[type='text']")).toHaveAttr('value','disabled textbox');
    // expect($('form')).toContainElement('div[id="hidden"]')
    // expect($('#hidden')).toHaveHtml('Div which is hidden !'); // exact match
   // expect($('#hidden')).toContainHtml('hidden'); // substring
     // expect($('#hidden')).toHaveCss({display:'none'})
     expect($('#hidden')).toHaveClass('customStyle');
});


beforeEach(function(){
    jasmine.getFixtures().fixturesPath = "../fixtures";
    loadFixtures('static.fixture.html')
})

it('use fixtures',function(){
    expect($('#hidden')).toHaveClass('customStyle');
})
});