describe('use ajax request',function(){
    it('test jquery ajax',function(done){
        $.get('https://jsonplaceholder.typicode.com/posts',function(response){
            expect(response.length).toBe(100);
            done();// tell jasmine to complete the spec
        })
    })
})

xdescribe('use async',function(){
    it('test async function',function(done){
     var x;
        setTimeout(function(){
            x = 1000;
            console.log('Inner Function called..')
            expect(x).toBe(1000);
            done();
        },3000);
    });
});

console.log('Program ended..')